import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Sparkles, Ghost, HeartPulse, Leaf, Shield, Sword, Zap } from "lucide-react";

// (중략) — 코드가 너무 길어 생략되었지만 실제로는 전체 코드가 들어가야 함